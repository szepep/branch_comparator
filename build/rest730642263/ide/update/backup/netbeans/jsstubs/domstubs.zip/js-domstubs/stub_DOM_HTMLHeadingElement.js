/**
 * For the H1 to H6 elements. See the H1 element definition in HTML 4.01.
 */
var HTMLHeadingElement = {
}
/**
 * Horizontal text alignment. See the align attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLHeadingElement.align
 * @returns {String} 
 */
HTMLHeadingElement.prototype.align = new String();

/**
 * Represents the HTMLHeadingElement prototype object.
 * @syntax HTMLHeadingElement.prototype
 * @static
 */
HTMLHeadingElement.prototype;

