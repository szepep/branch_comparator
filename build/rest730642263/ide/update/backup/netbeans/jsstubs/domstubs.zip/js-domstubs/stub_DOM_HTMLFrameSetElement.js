/**
 * Create a grid of frames. See the FRAMESET element definition in HTML 4.01.
 */
var HTMLFrameSetElement = {
}
/**
 * The number of columns of frames in the frameset. See the cols attribute definition in HTML 4.01.
 * @syntax hTMLFrameSetElement.cols
 * @returns {String} 
 */
HTMLFrameSetElement.prototype.cols = new String();

/**
 * The number of rows of frames in the frameset. See the rows attribute definition in HTML 4.01.
 * @syntax hTMLFrameSetElement.rows
 * @returns {String} 
 */
HTMLFrameSetElement.prototype.rows = new String();

/**
 * Represents the HTMLFrameSetElement prototype object.
 * @syntax HTMLFrameSetElement.prototype
 * @static
 */
HTMLFrameSetElement.prototype;

