/**
 * Event operations may throw an EventException as specified in their method descriptions.
 */
var EventException = {
}
/**
 * If the Event's type was not specified by initializing the event before the method was called. Specification of the Event's type as null or an empty string will also trigger this exception.
 * @syntax EventException.UNSPECIFIED_EVENT_TYPE_ERR
 * @returns {Number} 
 * @static
 */
EventException.UNSPECIFIED_EVENT_TYPE_ERR = new Number();

/**
 * Represents the EventException prototype object.
 * @syntax EventException.prototype
 * @static
 */
EventException.prototype;

