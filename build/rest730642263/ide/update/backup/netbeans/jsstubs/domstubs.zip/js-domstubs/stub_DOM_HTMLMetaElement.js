/**
 * This contains generic meta-information about the document. See the META element definition in HTML 4.01.
 */
var HTMLMetaElement = {
}
/**
 * Associated information. See the content attribute definition in HTML 4.01.
 * @syntax hTMLMetaElement.content
 * @returns {String} 
 */
HTMLMetaElement.prototype.content = new String();

/**
 * Select form of content. See the scheme attribute definition in HTML 4.01.
 * @syntax hTMLMetaElement.scheme
 * @returns {String} 
 */
HTMLMetaElement.prototype.scheme = new String();

/**
 * Meta information name. See the name attribute definition in HTML 4.01.
 * @syntax hTMLMetaElement.name
 * @returns {String} 
 */
HTMLMetaElement.prototype.name = new String();

/**
 * HTTP response header name [IETF RFC 2616]. See the http-equiv attribute definition in HTML 4.01.
 * @syntax hTMLMetaElement.httpEquiv
 * @returns {String} 
 */
HTMLMetaElement.prototype.httpEquiv = new String();

/**
 * Represents the HTMLMetaElement prototype object.
 * @syntax HTMLMetaElement.prototype
 * @static
 */
HTMLMetaElement.prototype;

