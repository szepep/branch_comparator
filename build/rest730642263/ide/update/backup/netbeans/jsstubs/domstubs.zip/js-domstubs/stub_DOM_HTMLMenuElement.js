/**
 * Menu list. See the MENU element definition in HTML 4.01. This element is deprecated in HTML 4.01.
 */
var HTMLMenuElement = {
}
/**
 * Reduce spacing between list items. See the compact attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLMenuElement.compact
 * @returns {boolean} 
 */
HTMLMenuElement.prototype.compact = new boolean();

/**
 * Represents the HTMLMenuElement prototype object.
 * @syntax HTMLMenuElement.prototype
 * @static
 */
HTMLMenuElement.prototype;

