/**
 * The document title. See the TITLE element definition in HTML 4.01.
 */
var HTMLTitleElement = {
}
/**
 * The specified title as a string.
 * @syntax hTMLTitleElement.text
 * @returns {String} 
 */
HTMLTitleElement.prototype.text = new String();

/**
 * Represents the HTMLTitleElement prototype object.
 * @syntax HTMLTitleElement.prototype
 * @static
 */
HTMLTitleElement.prototype;

