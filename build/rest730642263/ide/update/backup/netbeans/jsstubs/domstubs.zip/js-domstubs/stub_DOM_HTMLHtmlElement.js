/**
 * Root of an HTML document. See the HTML element definition in HTML 4.01.
 */
var HTMLHtmlElement = {
}
/**
 * Version information about the document's DTD. See the version attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLHtmlElement.version
 * @returns {String} 
 */
HTMLHtmlElement.prototype.version = new String();

/**
 * Represents the HTMLHtmlElement prototype object.
 * @syntax HTMLHtmlElement.prototype
 * @static
 */
HTMLHtmlElement.prototype;

