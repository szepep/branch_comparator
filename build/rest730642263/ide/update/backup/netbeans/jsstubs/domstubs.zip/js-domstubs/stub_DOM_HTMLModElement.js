/**
 * Notice of modification to part of a document. See the INS and DEL element definitions in HTML 4.01.
 */
var HTMLModElement = {
}
/**
 * A URI [IETF RFC 2396] designating a document that describes the reason for the change. See the cite attribute definition in HTML 4.01.
 * @syntax hTMLModElement.cite
 * @returns {String} 
 */
HTMLModElement.prototype.cite = new String();

/**
 * The date and time of the change. See the datetime attribute definition in HTML 4.01.
 * @syntax hTMLModElement.dateTime
 * @returns {String} 
 */
HTMLModElement.prototype.dateTime = new String();

/**
 * Represents the HTMLModElement prototype object.
 * @syntax HTMLModElement.prototype
 * @static
 */
HTMLModElement.prototype;

