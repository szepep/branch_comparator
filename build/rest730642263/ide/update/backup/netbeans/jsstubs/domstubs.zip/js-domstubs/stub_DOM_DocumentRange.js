/**
 */
var DocumentRange = {
}
/**
 * This interface can be obtained from the object implementing the Document interface using binding-specific casting methods.
 * @syntax documentRange.createRange()
 * @returns {Range} The initial state of the Range returned from this method is such that both of its boundary-points are positioned at the beginning of the corresponding Document, before any content. The Range returned can only be used to select content associated with this Document, or with DocumentFragments and Attrs for which this Document is the ownerDocument.
 */
DocumentRange.prototype.createRange = function() {};

/**
 * Represents the DocumentRange prototype object.
 * @syntax DocumentRange.prototype
 * @static
 */
DocumentRange.prototype;

