/**
 * Embedded image. See the IMG element definition in HTML 4.01.
 */
var HTMLImageElement = {
}
/**
 * Height of the image in pixels. See the height attribute definition in HTML 4.01. Note that the type of this attribute was DOMString in DOM Level 1 HTML [DOM Level 1].
 * @syntax hTMLImageElement.height
 * @returns {Number} 
 */
HTMLImageElement.prototype.height = new Number();

/**
 * Horizontal space to the left and right of this image in pixels. See the hspace attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01. Note that the type of this attribute was DOMString in DOM Level 1 HTML [DOM Level 1].
 * @syntax hTMLImageElement.hspace
 * @returns {Number} 
 */
HTMLImageElement.prototype.hspace = new Number();

/**
 * Alternate text for user agents not rendering the normal content of this element. See the alt attribute definition in HTML 4.01.
 * @syntax hTMLImageElement.alt
 * @returns {String} 
 */
HTMLImageElement.prototype.alt = new String();

/**
 * Aligns this object (vertically or horizontally) with respect to its surrounding text. See the align attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLImageElement.align
 * @returns {String} 
 */
HTMLImageElement.prototype.align = new String();

/**
 * The name of the element (for backwards compatibility).
 * @syntax hTMLImageElement.name
 * @returns {String} 
 */
HTMLImageElement.prototype.name = new String();

/**
 * The width of the image in pixels. See the width attribute definition in HTML 4.01. Note that the type of this attribute was DOMString in DOM Level 1 HTML [DOM Level 1].
 * @syntax hTMLImageElement.width
 * @returns {Number} 
 */
HTMLImageElement.prototype.width = new Number();

/**
 * URI [IETF RFC 2396] designating a long description of this image or frame. See the longdesc attribute definition in HTML 4.01.
 * @syntax hTMLImageElement.longDesc
 * @returns {String} 
 */
HTMLImageElement.prototype.longDesc = new String();

/**
 * Use server-side image map. See the ismap attribute definition in HTML 4.01.
 * @syntax hTMLImageElement.isMap
 * @returns {boolean} 
 */
HTMLImageElement.prototype.isMap = new boolean();

/**
 * URI [IETF RFC 2396] designating the source of this image. See the src attribute definition in HTML 4.01.
 * @syntax hTMLImageElement.src
 * @returns {String} 
 */
HTMLImageElement.prototype.src = new String();

/**
 * Width of border around image. See the border attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01. Note that the type of this attribute was DOMString in DOM Level 1 HTML [DOM Level 1].
 * @syntax hTMLImageElement.border
 * @returns {String} 
 */
HTMLImageElement.prototype.border = new String();

/**
 * Use client-side image map. See the usemap attribute definition in HTML 4.01.
 * @syntax hTMLImageElement.useMap
 * @returns {String} 
 */
HTMLImageElement.prototype.useMap = new String();

/**
 * Vertical space above and below this image in pixels. See the vspace attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01. Note that the type of this attribute was "DOMString" in DOM Level 1 HTML [DOM Level 1].
 * @syntax hTMLImageElement.vspace
 * @returns {Number} 
 */
HTMLImageElement.prototype.vspace = new Number();

/**
 * Represents the HTMLImageElement prototype object.
 * @syntax HTMLImageElement.prototype
 * @static
 */
HTMLImageElement.prototype;

