/**
 * @syntax isFinite(number)
 * @param {Number} number
 * @returns {Boolean}
 */
function isFinite(number) {};
