/**
 * @syntax new TypeError([message[, fileName[, lineNumber]]])
 * @param {String} 
 * @returns {Error}
 */
function TypeError() {
}
/**
 * @returns {String}
 * @static
 */
TypeError.name = new String();

/**
 * @returns {Function}
 * @static
 */
TypeError.constructor = new Function();

/**
 * @returns {Object}
 * @static
 */
TypeError.prototype;

