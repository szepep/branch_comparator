/**
 * @syntax new Function ([arg1[, arg2[, ... argN]],] functionBody)
 * @param {String} 
 * @returns {Function}
 */
function Function() {
}
/**
 * @syntax apply(thisArg,argArray)
 * @param {String} thisArg
 * @param {Object} argArray
 * @returns {Array}
 */
Function.prototype.apply = function(thisArg, argArray) {};

/**
 * @syntax call(thisArg[,arg1[,arg2,...]])
 * @param {Object} thisArg
 * @returns {String}
 */
Function.prototype.call = function(thisArg) {};

/**
 * @syntax length
 * @returns {Number}
 */
Function.prototype.length = new Number();

/**
 * @syntax toString()
 * @param {Number} 
 * @returns {String}
 */
Function.prototype.toString = function() {};

/**
 * @syntax bind(thisArg[,arg1[,arg2,...]])
 * @param {Object} thisArg
 * @returns {String}
 */
Function.prototype.bind = function(thisArg) {};

/**
 * @syntax constructor
 * @returns {Function}
 */
Function.prototype.constructor = new Function();

/**
 * @syntax prototype
 * @returns {Object}
 * @static
 */
Function.prototype;

