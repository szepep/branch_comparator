/**
 * @syntax NaN
 * @returns {Number}
 */
var NaN;
