/**
 * @syntax Infinity
 * @returns {Number}
 */
var Infinity;
