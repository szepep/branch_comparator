/**
 * @syntax new SyntaxError([message[, fileName[, lineNumber]]])
 * @param {String} 
 * @returns {Error}
 */
function SyntaxError() {
}
/**
 * @returns {String}
 * @static
 */
SyntaxError.name = new String();

/**
 * @returns {Function}
 * @static
 */
SyntaxError.constructor = new Function();

/**
 * @returns {Object}
 * @static
 */
SyntaxError.prototype;

