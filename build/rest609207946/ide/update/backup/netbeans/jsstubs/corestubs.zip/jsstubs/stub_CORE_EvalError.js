/**
 * @syntax new EvalError([message[, fileName[, lineNumber]]])
 * @param {String} 
 * @returns {Error}
 */
function EvalError() {
}
/**
 * @returns {String}
 */
EvalError.prototype.name = new String();

/**
 * @returns {Function}
 */
EvalError.prototype.constructor = new Function();

/**
 * @returns {Object}
 * @static
 */
EvalError.prototype;

